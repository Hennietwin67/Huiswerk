# Huiswerk Hulp
'n Eenvoudige Afrikaanse PWA-demo.

## Funksies
- Huiswerk byvoeg met datum
- Kalender
- Voltooi/verwyder take
- Afrikaanse stem-invoer waar die blaaier dit ondersteun
- Herinnering/notification-logika
- Data word plaaslik in die blaaier gestoor

## Belangrik
Die eerste weergawe is 'n front-end prototype. Betroubare agtergrond-notifications, rekening-sync en slim natuurlike-taal datumherkenning kan in 'n volgende weergawe bygevoeg word.
